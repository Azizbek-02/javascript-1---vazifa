let q = 5;
let w = 6;
for( let i = 1; i = w; i++){
    console.log(i);
    
}